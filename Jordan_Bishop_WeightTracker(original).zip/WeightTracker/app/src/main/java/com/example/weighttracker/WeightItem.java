package com.example.weighttracker;

public class WeightItem {
    public long id;
    public String dateIso;
    public double weight;

    public WeightItem(long id, String dateIso, double weight) {
        this.id = id;
        this.dateIso = dateIso;
        this.weight = weight;
    }
}
