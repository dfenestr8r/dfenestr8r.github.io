package com.example.weighttracker;

import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity implements WeightAdapter.RowActionListener {

    // --- Class-level variables ---
    private DatabaseHelper db;
    private long userId = 1; // Placeholder until login is linked
    private RecyclerView rv;
    private WeightAdapter adapter;
    private List<WeightItem> items;
    private Button btnAddWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize database helper
        db = new DatabaseHelper(this);

        // Initialize RecyclerView
        rv = findViewById(R.id.rvWeights);
        rv.setLayoutManager(new LinearLayoutManager(this));

        // Load existing weights from database or start empty
        items = db.getAllWeights();
        if (items == null) items = new ArrayList<>();

        // Initialize adapter
        adapter = new WeightAdapter(items, this);
        rv.setAdapter(adapter);

        // Set up Add Weight button
        btnAddWeight = findViewById(R.id.btnAddWeight);
        btnAddWeight.setOnClickListener(v -> promptAddWeight());
    }

    /**
     * Displays a popup dialog for the user to input a new weight.
     * Saves the new entry to the database and updates the RecyclerView.
     */
    private void promptAddWeight() {
        EditText inputWeight = new EditText(this);
        inputWeight.setHint("Weight (e.g., 175.4)");
        inputWeight.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        new AlertDialog.Builder(this)
                .setTitle("Add Weight")
                .setView(inputWeight)
                .setPositiveButton("Save", (dialog, which) -> {
                    String weightStr = inputWeight.getText().toString().trim();
                    if (weightStr.isEmpty()) {
                        Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double weightVal = Double.parseDouble(weightStr);
                    String dateIso = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                    // Insert new weight into database
                    long id = db.createWeight(userId, dateIso, weightVal);
                    if (id > -1) {
                        items.add(0, new WeightItem(id, dateIso, weightVal));
                        adapter.notifyItemInserted(0);
                        rv.scrollToPosition(0);
                        Toast.makeText(this, "Weight added!", Toast.LENGTH_SHORT).show();
                        // maybeNotifyGoalReached(weightVal);
                    } else {
                        Toast.makeText(this, "Failed to save weight", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Called when a user taps "Edit" in the RecyclerView.
     * Updates the selected weight in the database.
     */
    @Override
    public void onEdit(WeightItem item, int position) {
        EditText inputWeight = new EditText(this);
        inputWeight.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        inputWeight.setText(String.valueOf(item.weight));

        new AlertDialog.Builder(this)
                .setTitle("Edit Weight")
                .setView(inputWeight)
                .setPositiveButton("Update", (dialog, which) -> {
                    String weightStr = inputWeight.getText().toString().trim();
                    if (weightStr.isEmpty()) return;

                    double weightVal = Double.parseDouble(weightStr);
                    int rows = db.updateWeight(item.id, item.dateIso, weightVal);
                    if (rows > 0) {
                        item.weight = weightVal;
                        adapter.notifyItemChanged(position);
                        Toast.makeText(this, "Weight updated", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Called when a user taps "Delete" in the RecyclerView.
     * Removes the entry from the database and RecyclerView.
     */
    @Override
    public void onDelete(WeightItem item, int position) {
        int rows = db.deleteWeight(item.id);
        if (rows > 0) {
            items.remove(position);
            adapter.notifyItemRemoved(position);
            Toast.makeText(this, "Weight deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to delete weight", Toast.LENGTH_SHORT).show();
        }
    }
}
