package com.example.weighttracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Handles:
 *  - Login: verify username/password against DB
 *  - Create account: insert into users table if not exists
 * Then launches DashboardActivity with userId + username.
 */
public class MainActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, etPhone;
    private Button btnLogin, btnCreate;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DatabaseHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etPhone    = findViewById(R.id.etPhone);
        btnLogin   = findViewById(R.id.btnLogin);
        btnCreate  = findViewById(R.id.btnCreate);

        btnLogin.setOnClickListener(v -> doLogin());
        btnCreate.setOnClickListener(v -> doCreate());
    }

    private void doCreate() {
        String u = etUsername.getText().toString().trim();
        String p = etPassword.getText().toString().trim();
        String ph = etPhone.getText().toString().trim();

        if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
            Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Ensure user doesn't already exist
        Cursor c = db.getUserByUsername(u);
        if (c != null && c.moveToFirst()) {
            Toast.makeText(this, "User exists. Try login.", Toast.LENGTH_SHORT).show();
            c.close();
            return;
        }
        if (c != null) c.close();

        long id = db.createUser(u, p, ph);
        if (id > -1) {
            Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
            launchDashboard(id, u);
        } else {
            Toast.makeText(this, "Create failed (username taken?)", Toast.LENGTH_SHORT).show();
        }
    }

    private void doLogin() {
        String u = etUsername.getText().toString().trim();
        String p = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
            Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        Cursor c = db.getUserByUsername(u);
        if (c != null && c.moveToFirst()) {
            String pw = c.getString(c.getColumnIndexOrThrow(DatabaseHelper.U_PASSWORD));
            long userId = c.getLong(c.getColumnIndexOrThrow(DatabaseHelper.U_ID));
            c.close();
            if (p.equals(pw)) {
                Toast.makeText(this, "Login OK", Toast.LENGTH_SHORT).show();
                launchDashboard(userId, u);
            } else {
                Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show();
            }
        } else {
            if (c != null) c.close();
            Toast.makeText(this, "No account. Create one.", Toast.LENGTH_SHORT).show();
        }
    }

    private void launchDashboard(long userId, String username) {
        Intent i = new Intent(this, DashboardActivity.class);
        i.putExtra("userId", userId);
        i.putExtra("username", username);
        startActivity(i);
        finish();
    }
}
