package com.example.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddWeightActivity extends AppCompatActivity {
    EditText etWeight, etDate;
    Button btnSave;
    DatabaseHelper db;
    long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        db = new DatabaseHelper(this);
        userId = getIntent().getLongExtra("userId", -1);

        etWeight = findViewById(R.id.etWeightValue);
        etDate = findViewById(R.id.etDate);
        btnSave = findViewById(R.id.btnSaveWeight);

        // Sets default date to today
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        etDate.setHint(today);

        btnSave.setOnClickListener(v -> saveWeight());
    }

    private void saveWeight() {
        String wStr = etWeight.getText().toString().trim();
        String date = etDate.getText().toString().trim();
        if (TextUtils.isEmpty(wStr)) {
            Toast.makeText(this, "Enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }
        double weight = Double.parseDouble(wStr);
        if (TextUtils.isEmpty(date)) {
            date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        }
        long id = db.createWeight(userId, date, weight);
        if (id > -1) {
            Toast.makeText(this, "Weight saved", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Failed to save", Toast.LENGTH_SHORT).show();
        }
    }
}
