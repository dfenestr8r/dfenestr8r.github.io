package com.example.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter keeps UI code lean in the Activity.
 * Uses callbacks for Edit/Delete actions so DashboardActivity can perform DB ops.
 */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.VH> {

    public interface RowActionListener {
        void onEdit(WeightItem item, int position);
        void onDelete(WeightItem item, int position);
    }

    private final List<WeightItem> items;
    private final RowActionListener listener;

    public WeightAdapter(List<WeightItem> items, RowActionListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight, parent, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        WeightItem wi = items.get(pos);
        h.tvDate.setText(wi.dateIso);
        h.tvWeight.setText(String.valueOf(wi.weight));

        h.btnEdit.setOnClickListener(v -> {
            if (listener != null) listener.onEdit(wi, h.getAdapterPosition());
        });
        h.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDelete(wi, h.getAdapterPosition());
        });
    }

    @Override public int getItemCount() { return items.size(); }

    public void removeAt(int position) {
        items.remove(position);
        notifyItemRemoved(position);
    }

    public void updateAt(int position, WeightItem updated) {
        items.set(position, updated);
        notifyItemChanged(position);
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvDate, tvWeight;
        Button btnEdit, btnDelete;
        VH(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
