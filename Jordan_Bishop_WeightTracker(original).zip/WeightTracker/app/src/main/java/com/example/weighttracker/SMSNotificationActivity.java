package com.example.weighttracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SMSNotificationActivity extends AppCompatActivity {

    TextView tvPermissionStatus;
    Button btnSendNotification;

    // Permission launcher
    private ActivityResultLauncher<String> requestPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notifications);

        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        btnSendNotification = findViewById(R.id.btnSendNotification);

        // Setup permission request launcher
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        tvPermissionStatus.setText("SMS permission granted!");
                        btnSendNotification.setEnabled(true);
                    } else {
                        tvPermissionStatus.setText("SMS permission denied. Notifications will be disabled.");
                        btnSendNotification.setEnabled(false);
                    }
                }
        );

        checkSmsPermission();

        // Dummy send button
        btnSendNotification.setOnClickListener(v -> {
            // Just show a toast for now instead of sending real SMS
            Toast.makeText(SMSNotificationActivity.this,
                    "SMS Notification sent! (dummy)", Toast.LENGTH_SHORT).show();
        });
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED) {
            tvPermissionStatus.setText("SMS permission granted!");
            btnSendNotification.setEnabled(true);
        } else {
            tvPermissionStatus.setText("SMS permission not granted.");
            btnSendNotification.setEnabled(false);

            // Request permission
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }
}
