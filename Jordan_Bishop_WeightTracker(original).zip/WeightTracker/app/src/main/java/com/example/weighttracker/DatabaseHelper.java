package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * SQLite database helper:
 *  - users(id, username UNIQUE, password, phone)
 *  - weights(id, user_id FK, date_text ISO, weight REAL)
 *  - goal(id, user_id UNIQUE FK, goal_weight REAL)
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "weight_app.db";
    private static final int DB_VERSION = 1;

    // users
    public static final String T_USERS = "users";
    public static final String U_ID = "id";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";
    public static final String U_PHONE = "phone";

    // weights
    public static final String T_WEIGHTS = "weights";
    public static final String W_ID = "id";
    public static final String W_USER_ID = "user_id";
    public static final String W_DATE = "date_text";
    public static final String W_WEIGHT = "weight";

    // goal
    public static final String T_GOAL = "goal";
    public static final String G_ID = "id";
    public static final String G_USER_ID = "user_id";
    public static final String G_WEIGHT = "goal_weight";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " +
                "phone TEXT, " +
                "password TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "date TEXT, " +
                "weight REAL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + T_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + T_GOAL);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);
    }

    // ---------- USERS ----------
    public long createUser(String username, String password, String phone) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(U_USERNAME, username);
        cv.put(U_PASSWORD, password);
        cv.put(U_PHONE, phone);
        return db.insert(T_USERS, null, cv); // returns -1 on failure (e.g., UNIQUE violation)
    }

    public Cursor getUserByUsername(String username) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(T_USERS, null, U_USERNAME + "=?", new String[]{username}, null, null, null);
    }

    // ---------- GOAL ----------
    public void upsertGoal(long userId, Double goalWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(G_USER_ID, userId);
        cv.put(G_WEIGHT, goalWeight);

        Cursor c = db.query(T_GOAL, null, G_USER_ID + "=?", new String[]{String.valueOf(userId)}, null, null, null);
        boolean exists = (c != null && c.moveToFirst());
        if (c != null) c.close();

        if (exists) {
            db.update(T_GOAL, cv, G_USER_ID + "=?", new String[]{String.valueOf(userId)});
        } else {
            db.insert(T_GOAL, null, cv);
        }
    }

    public Double getGoal(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_GOAL, null, G_USER_ID + "=?", new String[]{String.valueOf(userId)}, null, null, null);
        if (c != null && c.moveToFirst()) {
            double g = c.getDouble(c.getColumnIndexOrThrow(G_WEIGHT));
            c.close();
            return g;
        }
        if (c != null) c.close();
        return null;
    }

    public String getUserPhone(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_USERS, new String[]{U_PHONE}, U_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, null);
        if (c != null && c.moveToFirst()) {
            String p = c.getString(c.getColumnIndexOrThrow(U_PHONE));
            c.close();
            return p;
        }
        if (c != null) c.close();
        return null;
    }

    // ---------- WEIGHTS (CRUD) ----------
    public long createWeight(long userId, String dateIso, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", dateIso);
        values.put("weight", weight);
        values.put("user_id", userId);
        return db.insert("weights", null, values);
    }

    public Cursor readWeights(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(T_WEIGHTS, null, W_USER_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, W_DATE + " DESC");
    }

    public int updateWeight(long id, String dateIso, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", dateIso);
        values.put("weight", weight);
        return db.update("weights", values, "id = ?", new String[]{String.valueOf(id)});
    }

    public int deleteWeight(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("weights", "id = ?", new String[]{String.valueOf(id)});
    }

    public List<WeightItem> getAllWeights() {
        List<WeightItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM weights ORDER BY date DESC", null);
        if (c.moveToFirst()) {
            do {
                long id = c.getLong(c.getColumnIndexOrThrow("id"));
                String date = c.getString(c.getColumnIndexOrThrow("date"));
                double weight = c.getDouble(c.getColumnIndexOrThrow("weight"));
                list.add(new WeightItem(id, date, weight));
            } while (c.moveToNext());
        }
        c.close();
        return list;
    }
}
