package cs320MobileApp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceComparisonTest {

    private static final int CONTACT_COUNT = 10_000;

    // Populates a HashMap-based service with CONTACT_COUNT contacts
    private ContactService buildHashMap() {
        ContactService service = new ContactService();
        for (int i = 0; i < CONTACT_COUNT; i++) {
            service.addContact(new Contact(
                String.valueOf(i), "First", "Last", "1234567890", "123 Main St"));
        }
        return service;
    }

    // Populates an ArrayList-based service with CONTACT_COUNT contacts
    private ContactServiceArrayList buildArrayList() {
        ContactServiceArrayList service = new ContactServiceArrayList();
        for (int i = 0; i < CONTACT_COUNT; i++) {
            service.addContact(new Contact(
                String.valueOf(i), "First", "Last", "1234567890", "123 Main St"));
        }
        return service;
    }

    @Test
    public void compareAddContact() {
        long start, end;

        start = System.nanoTime();
        buildHashMap();
        end = System.nanoTime();
        long hashMapTime = end - start;

        start = System.nanoTime();
        buildArrayList();
        end = System.nanoTime();
        long arrayListTime = end - start;

        System.out.printf("addContact x%,d%n", CONTACT_COUNT);
        System.out.printf("  HashMap:   %,d ns%n", hashMapTime);
        System.out.printf("  ArrayList: %,d ns%n", arrayListTime);
        System.out.printf("  ArrayList was %.2fx slower%n%n", (double) arrayListTime / hashMapTime);

        assertTrue(true);
    }

    @Test
    public void compareLookupContact() {
        ContactService hashMap = buildHashMap();
        ContactServiceArrayList arrayList = buildArrayList();

        // Look up the last-inserted contact (worst case for ArrayList)
        String targetId = String.valueOf(CONTACT_COUNT - 1);

        long start, end;

        start = System.nanoTime();
        for (int i = 0; i < CONTACT_COUNT; i++) {
            hashMap.getContactInfo(targetId);
        }
        end = System.nanoTime();
        long hashMapTime = end - start;

        start = System.nanoTime();
        for (int i = 0; i < CONTACT_COUNT; i++) {
            arrayList.getContactInfo(targetId);
        }
        end = System.nanoTime();
        long arrayListTime = end - start;

        System.out.printf("getContactInfo x%,d (worst-case target)%n", CONTACT_COUNT);
        System.out.printf("  HashMap:   %,d ns%n", hashMapTime);
        System.out.printf("  ArrayList: %,d ns%n", arrayListTime);
        System.out.printf("  ArrayList was %.2fx slower%n%n", (double) arrayListTime / hashMapTime);

        assertTrue(true);
    }

    @Test
    public void compareDeleteContact() {
        ContactService hashMap = buildHashMap();
        ContactServiceArrayList arrayList = buildArrayList();

        // Delete every contact one by one
        long start, end;

        start = System.nanoTime();
        for (int i = 0; i < CONTACT_COUNT; i++) {
            hashMap.deleteContact(String.valueOf(i));
        }
        end = System.nanoTime();
        long hashMapTime = end - start;

        start = System.nanoTime();
        for (int i = 0; i < CONTACT_COUNT; i++) {
            arrayList.deleteContact(String.valueOf(i));
        }
        end = System.nanoTime();
        long arrayListTime = end - start;

        System.out.printf("deleteContact x%,d%n", CONTACT_COUNT);
        System.out.printf("  HashMap:   %,d ns%n", hashMapTime);
        System.out.printf("  ArrayList: %,d ns%n", arrayListTime);
        System.out.printf("  ArrayList was %.2fx slower%n%n", (double) arrayListTime / hashMapTime);

        assertTrue(true);
    }
}
