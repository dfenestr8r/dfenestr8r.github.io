package cs320MobileApp;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    // Create a Date 5 seconds in the future
    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 5000); // 5 seconds later
    }

    // Create a Date 5 seconds in the past
    private Date getPastDate() {
        return new Date(System.currentTimeMillis() - 5000); // 5 seconds earlier
    }

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("12345", futureDate, "Checkup visit");

        assertEquals("12345", appt.getAppointmentID());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Checkup visit", appt.getDescription());
    }

    @Test
    public void testAppointmentIdNullThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getFutureDate(), "Visit");
        });
        assertEquals("Invalid appointment ID.", exception.getMessage());
    }

    @Test
    public void testAppointmentIdTooLongThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", getFutureDate(), "Visit");
        });
        assertEquals("Invalid appointment ID.", exception.getMessage());
    }

    @Test
    public void testAppointmentDateNullThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Visit");
        });
        assertEquals("Invalid date.", exception.getMessage());
    }

    @Test
    public void testAppointmentDateInPastThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getPastDate(), "Visit");
        });
        assertEquals("Invalid date.", exception.getMessage());
    }

    @Test
    public void testDescriptionNullThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getFutureDate(), null);
        });
        assertEquals("Invalid description.", exception.getMessage());
    }

    @Test
    public void testDescriptionTooLongThrowsException() {
        String longDescription = "This description is way too long and exceeds fifty characters!";
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getFutureDate(), longDescription);
        });
        assertEquals("Invalid description.", exception.getMessage());
    }

    @Test
    public void testAppointmentIdNotUpdatable() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("FIXEDID", futureDate, "Initial");

        // ID is final, so it can't be changed
        assertEquals("FIXEDID", appt.getAppointmentID());
    }
}
