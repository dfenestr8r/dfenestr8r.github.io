package cs320MobileApp;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    
    // Store tasks in a HashMap using taskId as the key
    private final Map<String, Task> tasks;

    public TaskService() {
    	
        tasks = new HashMap<>();
        
    }

    // Adds new task with unique ID
    public void addTask(Task task) {
    	
        if (task == null || tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists or task is null.");
        }
        
        tasks.put(task.getTaskId(), task);
    }

    // Deletes task by ID
    public void deleteTask(String taskId) {
    	
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        
        tasks.remove(taskId);
    }

    // Updates task name
    public void updateTaskName(String taskId, String newName) {
    	
        Task task = tasks.get(taskId);
        
        if (task == null) {
        	throw new IllegalArgumentException("Task ID not found.");
        }
        
        task.setName(newName);
    }

    // Updates task description
    public void updateTaskDescription(String taskId, String newDescription) {
    	
        Task task = tasks.get(taskId);
        
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        
        task.setDescription(newDescription);
    }
}
