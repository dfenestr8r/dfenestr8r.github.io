package cs320MobileApp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService contactService;
    private Contact sampleContact;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
        sampleContact = new Contact("A001", "Rick", "Grimes", "1234567890", "Alexandria");
        contactService.addContact(sampleContact);
    }

    @Test
    public void testAddValidContact() {
        Contact newContact = new Contact("A002", "Daryl", "Dixon", "0987654321", "The Woods");
        contactService.addContact(newContact);
        assertEquals("Daryl", contactService.getContactInfo("A002").getFirstName());
    }

    @Test
    public void testAddDuplicateContactIdThrowsException() {
        Contact duplicate = new Contact("A001", "Carl", "Grimes", "1112223333", "Alexandria");
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(duplicate));
    }

    @Test
    public void testDeleteExistingContact() {
        contactService.deleteContact("A001");
        assertThrows(IllegalArgumentException.class, () -> contactService.getContactInfo("A001"));
    }

    @Test
    public void testDeleteNonExistentContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> contactService.deleteContact("BADID"));
    }

    @Test
    public void testUpdateFirstName() {
        contactService.updateFirstName("A001", "Shane");
        assertEquals("Shane", contactService.getContactInfo("A001").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        contactService.updateLastName("A001", "Walsh");
        assertEquals("Walsh", contactService.getContactInfo("A001").getLastName());
    }

    @Test
    public void testUpdatePhone() {
        contactService.updatePhone("A001", "9998887777");
        assertEquals("9998887777", contactService.getContactInfo("A001").getPhone());
    }

    @Test
    public void testUpdateAddress() {
        contactService.updateAddress("A001", "Hilltop Colony");
        assertEquals("Hilltop Colony", contactService.getContactInfo("A001").getAddress());
    }

    @Test
    public void testUpdateFirstNameInvalidValueThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> contactService.updateFirstName("A001", null));
        assertThrows(IllegalArgumentException.class, () -> contactService.updateFirstName("A001", "WayTooLongName"));
    }

    @Test
    public void testUpdatePhoneInvalidValueThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> contactService.updatePhone("A001", "badnumber"));
    }

    @Test
    public void testUpdateNonExistentContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> contactService.updateLastName("B002", "Smith"));
    }

    @Test
    public void testGetContactInfoReturnsCorrectContact() {
        Contact fetched = contactService.getContactInfo("A001");
        assertEquals("Rick", fetched.getFirstName());
        assertEquals("Grimes", fetched.getLastName());
    }

    @Test
    public void testGetContactInfoWithInvalidIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> contactService.getContactInfo("ZZZ"));
    }
}