package cs320MobileApp;

import java.util.ArrayList;
import java.util.List;

public class ContactServiceArrayList {

    private final List<Contact> contacts = new ArrayList<>();

    private Contact findContact(String contactId) {
        for (Contact c : contacts) {
            if (c.getContactId().equals(contactId)) {
                return c;
            }
        }
        return null;
    }

    public void addContact(Contact contact) {
        if (findContact(contact.getContactId()) != null) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.add(contact);
    }

    public void deleteContact(String contactId) {
        Contact contact = findContact(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID does not exist");
        }
        contacts.remove(contact);
    }

    public void updateFirstName(String contactId, String newFirstName) {
        getContact(contactId).setFirstName(newFirstName);
    }

    public void updateLastName(String contactId, String newLastName) {
        getContact(contactId).setLastName(newLastName);
    }

    public void updatePhone(String contactId, String newPhone) {
        getContact(contactId).setPhone(newPhone);
    }

    public void updateAddress(String contactId, String newAddress) {
        getContact(contactId).setAddress(newAddress);
    }

    private Contact getContact(String contactId) {
        Contact contact = findContact(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID does not exist");
        }
        return contact;
    }

    public Contact getContactInfo(String contactId) {
        return getContact(contactId);
    }
}
