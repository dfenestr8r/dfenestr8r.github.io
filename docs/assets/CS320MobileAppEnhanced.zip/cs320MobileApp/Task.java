package cs320MobileApp;

public class Task {

	// Initializes class variables
	private final String taskId;
	private String name;
	private String description;
	
	public Task(String taskId, String name, String description) {
		
		// Validates input
		if (taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException("Invalid task ID.");
		}
		
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name.");
		}
		
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description.");
		}
		
		// Assigns constructor variables to object
		this.taskId = taskId;
		this.setName(name);
		this.setDescription(description);
	}

	// Getters and setters
	public String getTaskId() {
		return taskId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name.");
		}
		
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			
			throw new IllegalArgumentException("Invalid description.");
		}
		
		this.description = description;
	}
}
