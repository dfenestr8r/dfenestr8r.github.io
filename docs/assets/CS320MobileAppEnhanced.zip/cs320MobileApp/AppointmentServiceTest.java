package cs320MobileApp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appointment;

    // Helper method to get a future date
    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 5000); // 5 seconds in future
    }

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        appointment = new Appointment("A001", getFutureDate(), "Dental checkup");
    }

    @Test
    public void testAddAppointmentSuccessfully() {
        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("A001"));
    }

    @Test
    public void testAddAppointmentWithDuplicateIDThrowsException() {
        service.addAppointment(appointment);
        Appointment duplicate = new Appointment("A001", getFutureDate(), "Duplicate");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(duplicate);
        });
        assertEquals("Duplicate appointment ID.", exception.getMessage());
    }

    @Test
    public void testAddNullAppointmentThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
        assertEquals("Appointment or appointment ID cannot be null.", exception.getMessage());
    }

    @Test
    public void testDeleteAppointmentSuccessfully() {
        service.addAppointment(appointment);
        service.deleteAppointment("A001");
        assertNull(service.getAppointment("A001"));
    }

    @Test
    public void testDeleteNonexistentAppointmentThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("NONEXISTENT");
        });
        assertEquals("Appointment ID not found.", exception.getMessage());
    }

    @Test
    public void testDeleteWithNullIDThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment(null);
        });
        assertEquals("Appointment ID cannot be null.", exception.getMessage());
    }
}
