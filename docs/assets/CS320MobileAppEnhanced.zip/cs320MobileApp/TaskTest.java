package cs320MobileApp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("T001", "Inspect Wall", "Inspect the west perimeter wall for breaches.");
        assertEquals("T001", task.getTaskId());
        assertEquals("Inspect Wall", task.getName());
        assertEquals("Inspect the west perimeter wall for breaches.", task.getDescription());
    }

    @Test
    public void testNullTaskIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Guard Duty", "Stand watch from dusk till dawn.");
        });
    }

    @Test
    public void testLongTaskIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("TOO_LONG_TASK_ID", "Guard Duty", "Stand watch from dusk till dawn.");
        });
    }

    @Test
    public void testNullNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T002", null, "Secure the north gate.");
        });
    }

    @Test
    public void testLongNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T003", "A very long task name that exceeds the limit", "Secure the north gate.");
        });
    }

    @Test
    public void testNullDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T004", "Patrol", null);
        });
    }

    @Test
    public void testLongDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T005", "Patrol", "This description is way too long and should definitely exceed fifty characters in length.");
        });
    }

    @Test
    public void testSetNameWithValidValue() {
        Task task = new Task("T006", "Scout", "Check the woods for movement.");
        task.setName("Recon");
        assertEquals("Recon", task.getName());
    }

    @Test
    public void testSetNameWithNullThrowsException() {
        Task task = new Task("T007", "Defend", "Guard the front gate.");
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
    }

    @Test
    public void testSetNameWithLongValueThrowsException() {
        Task task = new Task("T008", "Defend", "Guard the front gate.");
        assertThrows(IllegalArgumentException.class, () -> task.setName("This is a ridiculously long name"));
    }

    @Test
    public void testSetDescriptionWithValidValue() {
        Task task = new Task("T009", "Clean", "Clean up the supply room.");
        task.setDescription("Sweep the training yard.");
        assertEquals("Sweep the training yard.", task.getDescription());
    }

    @Test
    public void testSetDescriptionWithNullThrowsException() {
        Task task = new Task("T010", "Cook", "Prepare meals for everyone.");
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
    }

    @Test
    public void testSetDescriptionWithLongValueThrowsException() {
        Task task = new Task("T011", "Cook", "Prepare meals for everyone.");
        assertThrows(IllegalArgumentException.class, () -> task.setDescription("This description is extremely long and surpasses the fifty-character restriction."));
    }

    @Test
    public void testTaskIdIsImmutable() {
        Task task = new Task("T012", "Watchtower", "Keep lookout for walkers.");
        // No setter exists, so just verify it remains unchanged
        assertEquals("T012", task.getTaskId());
    }
}
