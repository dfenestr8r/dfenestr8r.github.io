package cs320MobileApp;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();

    // Add a new appointment
    public void addAppointment(Appointment appointment) {
    	
        if (appointment == null || appointment.getAppointmentID() == null) {
            throw new IllegalArgumentException("Appointment or appointment ID cannot be null.");
        }

        if (appointments.containsKey(appointment.getAppointmentID())) {
            throw new IllegalArgumentException("Duplicate appointment ID.");
        }

        appointments.put(appointment.getAppointmentID(), appointment);
    }

    // Delete an appointment by ID
    public void deleteAppointment(String appointmentID) {
    	
        if (appointmentID == null) {
            throw new IllegalArgumentException("Appointment ID cannot be null.");
        }

        if (!appointments.containsKey(appointmentID)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }

        appointments.remove(appointmentID);
    }

    // Retrieve appointment (for testing)
    public Appointment getAppointment(String appointmentID) {
        return appointments.get(appointmentID);
    }
}