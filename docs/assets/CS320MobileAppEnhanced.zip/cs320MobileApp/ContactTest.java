package cs320MobileApp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("12345", "Rick", "Grimes", "1234567890", "Alexandria Safe-Zone");
        assertEquals("12345", contact.getContactId());
        assertEquals("Rick", contact.getFirstName());
        assertEquals("Grimes", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("Alexandria Safe-Zone", contact.getAddress());
    }

    @Test
    public void testNullContactIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Rick", "Grimes", "1234567890", "Alexandria");
        });
    }

    @Test
    public void testLongContactIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Rick", "Grimes", "1234567890", "Alexandria");
        });
    }

    @Test
    public void testNullFirstNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", null, "Grimes", "1234567890", "Alexandria");
        });
    }

    @Test
    public void testLongFirstNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "VeryLongNameX", "Grimes", "1234567890", "Alexandria");
        });
    }

    @Test
    public void testNullLastNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Rick", null, "1234567890", "Alexandria");
        });
    }

    @Test
    public void testLongLastNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Rick", "SuperLongLastName", "1234567890", "Alexandria");
        });
    }

    @Test
    public void testInvalidPhoneTooShortThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Rick", "Grimes", "1234567", "Alexandria");
        });
    }

    @Test
    public void testInvalidPhoneTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Rick", "Grimes", "123456789012", "Alexandria");
        });
    }

    @Test
    public void testPhoneContainsNonDigitsThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Rick", "Grimes", "12345abcde", "Alexandria");
        });
    }

    @Test
    public void testNullPhoneThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Rick", "Grimes", null, "Alexandria");
        });
    }

    @Test
    public void testNullAddressThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Rick", "Grimes", "1234567890", null);
        });
    }

    @Test
    public void testLongAddressThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Rick", "Grimes", "1234567890", "This address is definitely way too long");
        });
    }

    @Test
    public void testSettersWithValidValues() {
        Contact contact = new Contact("321", "Daryl", "Dixon", "0987654321", "The Woods");
        contact.setFirstName("Carol");
        contact.setLastName("Peletier");
        contact.setPhone("1112223333");
        contact.setAddress("Kingdom");

        assertEquals("Carol", contact.getFirstName());
        assertEquals("Peletier", contact.getLastName());
        assertEquals("1112223333", contact.getPhone());
        assertEquals("Kingdom", contact.getAddress());
    }

    @Test
    public void testSetFirstNameWithInvalidValueThrowsException() {
        Contact contact = new Contact("456", "Carl", "Grimes", "2223334444", "Alexandria");
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("WayTooLongName"));
    }

    @Test
    public void testSetLastNameWithInvalidValueThrowsException() {
        Contact contact = new Contact("456", "Carl", "Grimes", "2223334444", "Alexandria");
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("ExtremelyLongLastName"));
    }

    @Test
    public void testSetPhoneWithInvalidValueThrowsException() {
        Contact contact = new Contact("456", "Carl", "Grimes", "2223334444", "Alexandria");
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("1234x67890"));
    }

    @Test
    public void testSetAddressWithInvalidValueThrowsException() {
        Contact contact = new Contact("456", "Carl", "Grimes", "2223334444", "Alexandria");
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("A very long address that should not be accepted by the setter"));
    }
}