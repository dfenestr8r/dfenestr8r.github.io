package cs320MobileApp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService taskService;
    private Task baseTask;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
        baseTask = new Task("T001", "Guard Duty", "Stand watch at the main gate.");
        taskService.addTask(baseTask);
    }

    @Test
    public void testAddValidTask() {
        Task newTask = new Task("T002", "Repair Fence", "Fix the broken west fence section.");
        taskService.addTask(newTask);
        // No exception means success; verify with update
        taskService.updateTaskName("T002", "Fence Repair");
        assertEquals("Fence Repair", newTask.getName());
    }

    @Test
    public void testAddTaskWithDuplicateIdThrowsException() {
        Task duplicate = new Task("T001", "Scouting", "Scout north perimeter.");
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(duplicate));
    }

    @Test
    public void testAddNullTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(null));
    }

    @Test
    public void testDeleteExistingTask() {
        taskService.deleteTask("T001");
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("T001", "Empty"));
    }

    @Test
    public void testDeleteNonexistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("NOPE123"));
    }

    @Test
    public void testUpdateTaskNameSuccessfully() {
        taskService.updateTaskName("T001", "Watch Duty");
        assertEquals("Watch Duty", baseTask.getName());
    }

    @Test
    public void testUpdateTaskNameInvalidIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("BADID", "New Name"));
    }

    @Test
    public void testUpdateTaskNameWithInvalidValueThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("T001", null));
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("T001", "NameThatIsWayTooLongToBeAccepted"));
    }

    @Test
    public void testUpdateTaskDescriptionSuccessfully() {
        taskService.updateTaskDescription("T001", "Monitor the wall and lookout posts.");
        assertEquals("Monitor the wall and lookout posts.", baseTask.getDescription());
    }

    @Test
    public void testUpdateTaskDescriptionInvalidIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskDescription("UNKNOWN", "Test description"));
    }

    @Test
    public void testUpdateTaskDescriptionWithInvalidValueThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskDescription("T001", null));
        assertThrows(IllegalArgumentException.class, () ->
                taskService.updateTaskDescription("T001", "This description is far too long and exceeds the fifty character limit allowed."));
    }
}