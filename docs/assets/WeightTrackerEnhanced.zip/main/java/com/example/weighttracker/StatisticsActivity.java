package com.example.weighttracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class StatisticsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        long userId = getIntent().getLongExtra("userId", 1);
        DatabaseHelper db = new DatabaseHelper(this);

        // Load weights sorted ascending by date for MA computation
        List<WeightItem> allWeights = db.getAllWeights(userId);
        // getAllWeights returns DESC; reverse to get ASC for window math
        List<WeightItem> asc = new ArrayList<>(allWeights);
        Collections.reverse(asc);

        // --- Summary stats ---
        TextView tvLatest = findViewById(R.id.tvLatest);
        TextView tvMin = findViewById(R.id.tvMin);
        TextView tvMax = findViewById(R.id.tvMax);

        if (!asc.isEmpty()) {
            double latest = asc.get(asc.size() - 1).weight;
            double min = asc.get(0).weight;
            double max = asc.get(0).weight;
            for (WeightItem w : asc) {
                if (w.weight < min) min = w.weight;
                if (w.weight > max) max = w.weight;
            }
            tvLatest.setText(String.format(Locale.getDefault(), "%.1f", latest));
            tvMin.setText(String.format(Locale.getDefault(), "%.1f", min));
            tvMax.setText(String.format(Locale.getDefault(), "%.1f", max));
        }

        // --- Compute per-entry moving averages ---
        List<StatRow> rows = new ArrayList<>();
        for (int i = 0; i < asc.size(); i++) {
            WeightItem item = asc.get(i);
            double avg7 = windowAverage(asc, i, 7);
            double avg30 = windowAverage(asc, i, 30);
            rows.add(new StatRow(item.dateIso, item.weight, avg7, avg30,
                    Math.min(i + 1, 7), Math.min(i + 1, 30)));
        }

        // Show most recent entries first in the table
        Collections.reverse(rows);

        // --- Current (most recent) 7-day and 30-day averages ---
        TextView tv7day = findViewById(R.id.tv7day);
        TextView tv30day = findViewById(R.id.tv30day);
        TextView tv7dayCount = findViewById(R.id.tv7dayCount);
        TextView tv30dayCount = findViewById(R.id.tv30dayCount);

        if (!rows.isEmpty()) {
            StatRow latest = rows.get(0);
            tv7day.setText(String.format(Locale.getDefault(), "%.1f", latest.avg7));
            tv30day.setText(String.format(Locale.getDefault(), "%.1f", latest.avg30));
            tv7dayCount.setText(latest.count7 + " entries");
            tv30dayCount.setText(latest.count30 + " entries");
        } else {
            tv7day.setText("--");
            tv30day.setText("--");
        }

        // --- Table RecyclerView ---
        RecyclerView rv = findViewById(R.id.rvStats);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(new StatAdapter(rows));
    }

    private double windowAverage(List<WeightItem> asc, int idx, int window) {
        int start = Math.max(0, idx - window + 1);
        double sum = 0;
        for (int j = start; j <= idx; j++) {
            sum += asc.get(j).weight;
        }
        return sum / (idx - start + 1);
    }

    // --- Data model ---
    static class StatRow {
        String date;
        double weight, avg7, avg30;
        int count7, count30;

        StatRow(String date, double weight, double avg7, double avg30, int count7, int count30) {
            this.date = date;
            this.weight = weight;
            this.avg7 = avg7;
            this.avg30 = avg30;
            this.count7 = count7;
            this.count30 = count30;
        }
    }

    // --- RecyclerView Adapter ---
    static class StatAdapter extends RecyclerView.Adapter<StatAdapter.VH> {
        private final List<StatRow> rows;

        StatAdapter(List<StatRow> rows) {
            this.rows = rows;
        }

        @Override
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_stat_row, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH h, int position) {
            StatRow r = rows.get(position);
            h.tvDate.setText(r.date);
            h.tvWeight.setText(String.format(Locale.getDefault(), "%.1f", r.weight));
            h.tv7.setText(String.format(Locale.getDefault(), "%.1f", r.avg7));
            h.tv30.setText(String.format(Locale.getDefault(), "%.1f", r.avg30));
        }

        @Override
        public int getItemCount() {
            return rows.size();
        }

        static class VH extends RecyclerView.ViewHolder {
            TextView tvDate, tvWeight, tv7, tv30;

            VH(View v) {
                super(v);
                tvDate = v.findViewById(R.id.tvDate);
                tvWeight = v.findViewById(R.id.tvWeight);
                tv7 = v.findViewById(R.id.tv7);
                tv30 = v.findViewById(R.id.tv30);
            }
        }
    }
}
