package com.example.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity implements WeightAdapter.RowActionListener {

    // --- Class-level variables ---
    private DatabaseHelper db;
    private long userId = 1;
    private String username = "User";
    private Double currentGoal;
    private RecyclerView rv;
    private WeightAdapter adapter;
    private List<WeightItem> items;
    private Button btnAddWeight;
    private TextView tvWelcome, tvGoal;
    private Button btnSetGoal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        userId = getIntent().getLongExtra("userId", 1);
        String intentName = getIntent().getStringExtra("username");
        if (intentName != null) username = intentName;

        db = new DatabaseHelper(this);

        tvWelcome = findViewById(R.id.tvWelcome);
        tvGoal = findViewById(R.id.tvGoal);
        btnSetGoal = findViewById(R.id.btnSetGoal);

        tvWelcome.setText("Welcome, " + username + "!");
        loadGoal();
        btnSetGoal.setOnClickListener(v -> promptSetGoal());

        rv = findViewById(R.id.rvWeights);
        rv.setLayoutManager(new LinearLayoutManager(this));

        // Load existing weights from database or start empty
        items = db.getAllWeights(userId);
        if (items == null) items = new ArrayList<>();

        // Initialize adapter
        adapter = new WeightAdapter(items, this, currentGoal);
        rv.setAdapter(adapter);

        // Set up Add Weight button
        btnAddWeight = findViewById(R.id.btnAddWeight);
        btnAddWeight.setOnClickListener(v -> promptAddWeight());

        // Set up Statistics button
        findViewById(R.id.btnStatistics).setOnClickListener(v -> {
            Intent i = new Intent(this, StatisticsActivity.class);
            i.putExtra("userId", userId);
            startActivity(i);
        });
    }

    private void loadGoal() {
        currentGoal = db.getGoal(userId);
        tvGoal.setText(currentGoal != null ? "Goal: " + currentGoal + " lbs" : "Goal: not set");
        if (adapter != null) adapter.setGoal(currentGoal);
    }

    private void promptSetGoal() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setHint("Goal weight (lbs)");
        Double current = db.getGoal(userId);
        if (current != null) input.setText(String.valueOf(current));

        new AlertDialog.Builder(this)
                .setTitle("Set Goal Weight")
                .setView(input)
                .setPositiveButton("Save", (dialog, which) -> {
                    String s = input.getText().toString().trim();
                    if (s.isEmpty()) return;
                    db.upsertGoal(userId, Double.parseDouble(s));
                    loadGoal();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Displays a popup dialog for the user to input a new weight.
     * Saves the new entry to the database and updates the RecyclerView.
     */
    private void promptAddWeight() {
        EditText inputWeight = new EditText(this);
        inputWeight.setHint("Weight (e.g., 175.4)");
        inputWeight.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        new AlertDialog.Builder(this)
                .setTitle("Add Weight")
                .setView(inputWeight)
                .setPositiveButton("Save", (dialog, which) -> {
                    String weightStr = inputWeight.getText().toString().trim();
                    if (weightStr.isEmpty()) {
                        Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double weightVal = Double.parseDouble(weightStr);
                    String dateIso = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                    // Insert new weight into database
                    long id = db.createWeight(userId, dateIso, weightVal);
                    if (id > -1) {
                        items.add(0, new WeightItem(id, dateIso, weightVal));
                        adapter.notifyItemInserted(0);
                        rv.scrollToPosition(0);
                        Toast.makeText(this, "Weight added!", Toast.LENGTH_SHORT).show();
                        // maybeNotifyGoalReached(weightVal);
                    } else {
                        Toast.makeText(this, "Failed to save weight", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Called when a user taps "Edit" in the RecyclerView.
     * Updates the selected weight in the database.
     */
    @Override
    public void onEdit(WeightItem item, int position) {
        EditText inputWeight = new EditText(this);
        inputWeight.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        inputWeight.setText(String.valueOf(item.weight));

        new AlertDialog.Builder(this)
                .setTitle("Edit Weight")
                .setView(inputWeight)
                .setPositiveButton("Update", (dialog, which) -> {
                    String weightStr = inputWeight.getText().toString().trim();
                    if (weightStr.isEmpty()) return;

                    double weightVal = Double.parseDouble(weightStr);
                    int rows = db.updateWeight(item.id, item.dateIso, weightVal);
                    if (rows > 0) {
                        item.weight = weightVal;
                        adapter.notifyItemChanged(position);
                        Toast.makeText(this, "Weight updated", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Called when a user taps "Delete" in the RecyclerView.
     * Removes the entry from the database and RecyclerView.
     */
    @Override
    public void onDelete(WeightItem item, int position) {
        int rows = db.deleteWeight(item.id);
        if (rows > 0) {
            items.remove(position);
            adapter.notifyItemRemoved(position);
            Toast.makeText(this, "Weight deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to delete weight", Toast.LENGTH_SHORT).show();
        }
    }
}
